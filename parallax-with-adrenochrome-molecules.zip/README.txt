A Pen created at CodePen.io. You can find this one at http://codepen.io/Sander-Nizni/pen/XdGNgR.

 You didn't know this was adrenochrome? No one did. But this visualization is a valid hypothesis. If this doesn't sit well with you, think of this visualization as something else, such as alcohol or ibuprofen... or a meringue pie. 